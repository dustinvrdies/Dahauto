def find_faucets():
    return [
        {"name": "FreeBitco.in", "url": "https://freebitco.in"},
        {"name": "Cointiply", "url": "https://cointiply.com"},
        {"name": "Fire Faucet", "url": "https://firefaucet.win"}
    ]
